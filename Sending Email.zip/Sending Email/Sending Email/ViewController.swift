//
//  ViewController.swift
//  Sending Email
//
//  Created by MAC on 17/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit
import MessageUI

class ViewController: UIViewController, MFMailComposeViewControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func ClickToSendMail(_ sender: Any) {
        
        if MFMailComposeViewController.canSendMail(){
        
         let controller = MFMailComposeViewController()
         controller.mailComposeDelegate = self
         controller.setToRecipients(["nikunj.smarttechnica@gmail.com"])
         controller.setSubject("Mail Demo")
         controller.setMessageBody("This is Only Demo Mail", isHTML: true)
         print(controller)
         self.present(controller, animated: true, completion: nil)
        }
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        
        switch result {
        case .sent:
            print("sent")
            
        case .cancelled:
            print("cancelled")
            
        case .failed:
            print("failed")
            
        }
        
        controller.dismiss(animated: true, completion: nil)
    }
}

